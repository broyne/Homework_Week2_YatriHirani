package homework_week_2;

import java.util.Scanner;

public class Programme18 {
    /**
     * Write a Java program to print the sum (addition), multiply, subtract, divide and
     * remainder of two numbers.
     * Test Data:
     * Input first number: 125
     * Input second number: 24
     * Expected Output :
     * 125 + 24 = 149
     * 125 - 24 = 101
     * 125 x 24 = 3000
     * 125 / 24 = 5
     * 125 mod 24 = 5
     */

    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);
        //tonum();
    }

    public static void tonum(int a, int b) {
        int addition = a + b;
        int sustraction = a - b;
        int multiplication = a * b;
        int mod = a % b;

        System.out.println("The Addition of 125 and 24 is: + addition");
    }


}
